<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="style/admin.css">
    </head>
    <body>
        <div class="sidenav">
            <a href="addTopping.php">Add Topping</a>
            <a href="deleteTopping.php">Delete Topping</a>
            <a href="addKasir.php">Add Kasir</a>
            <a href="deleteKasir.php">Delete Kasir</a>
            <a href="menuLaporan.php">Laporan</a>
            <a href="halamanUtama.php">Log Out</a>
        </div>
        <div class="main">
            <h2>Welcome Admin!</h2>
            <p>Silahkan pilih menu anda.</p>
        </div>
    </body>
</html>