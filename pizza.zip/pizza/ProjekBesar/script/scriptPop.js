function fungsiPopAddKasir(){
	alert("Penambahan Kasir Berhasil!");
}

function fungsiPopDeleteKasir(){
	alert("Penghapusan Kasir Berhasil!");
}