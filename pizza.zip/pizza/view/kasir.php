<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="view/style/kasir.css">
    </head>
    <body>
        <div class="main">
            <h2>Welcome Kasir!</h2>
            <p>Silahkan pilih menu anda.</p>
        </div>
    </body>
</html>