<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="view/style/admin.css">
    </head>
    <body>
        <div class="main">
            <h2>Welcome Admin!</h2>
            <p>Silahkan pilih menu anda.</p>
        </div>
    </body>
</html>