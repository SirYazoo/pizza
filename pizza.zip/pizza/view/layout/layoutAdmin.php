<!DOCTYPE html>
<html>
<head>
</head>
<body>
    <div class="sidenav">
        <a href="addTopping">Add Topping</a>
        <a href="deleteTopping">Delete Topping</a>
        <a href="addKasir">Add Kasir</a>
        <a href="deleteKasir">Delete Kasir</a>
        <a href="menuLaporan">Laporan</a>
        <a href="logout">Log Out</a>
    </div>
    <?php echo $content; ?>
</body>
</html>