<!DOCTYPE html>
<html>
<head>
</head>
<body>
    <div class="sidenav">
        <a href="menuPembelian.php">Menu Pembelian</a>
        <a href="halamanUtama.php">Log Out</a>
    </div>
    <?php echo $content; ?>
</body>
</html>